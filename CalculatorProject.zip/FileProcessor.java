import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileProcessor {

    /**
     * Processes arithmetic expressions line-by-line in the given file.
     *
     * @param filePath Path to a file containing arithmetic expressions.
     */
    public static void processFile(String filePath) {
        File infile = new File(filePath);
        int count = 0;
        File infile2 = new File(filePath);


        try (Scanner scan = new Scanner(infile)) {
//
            while (scan.hasNext()) {
                // TODO: Process each line of the input file here.
                String input = scan.nextLine();
                String plus = "+";
                String multi = "*";
                String ex = "^";
                if (input.contains(plus)) {
                    int start = 0;
                    for (int i=0; i < input.length(); i++) {
                        if (input.charAt(i) == '+') {
                            start = i;
                        }
                    }

                    String first = input.substring(0, start);
                    String second = input.substring(start + 1);
                    String firstVal = "";
                    String secondVal = "";

                    for (int i=0; i < first.length(); i++) {
                        if (first.charAt(i) != ' ') {
                            firstVal = firstVal + first.charAt(i);
                        }
                    }
                    for (int i=0; i < second.length(); i++) {
                        if (second.charAt(i) != ' ') {
                            secondVal = secondVal + second.charAt(i);
                        }
                    }

                    LinkedListS<Integer> val1 = new LinkedListS<>();
                    LinkedListS<Integer> val2 = new LinkedListS<>();

                    for (int i = firstVal.length() - 1; i >= 0; i--) {
                        String insert = firstVal.substring(i, i+1);
                        int val = Integer.parseInt(insert);
                        val1.add(val);
                    }

                    for (int i = secondVal.length() - 1; i >= 0; i--) {
                        String insert = secondVal.substring(i, i + 1);
                        int val = Integer.parseInt(insert);
                        val2.add(val);
                    }
                    Arithmetic.add1(val1, val2);

                }

                else if (input.contains(multi)) {
                    int start = 0;
                    for (int i=0; i < input.length(); i++) {
                        if (input.charAt(i) == '*') {
                            start = i;
                        }
                    }

                    String first = input.substring(0, start);
                    String second = input.substring(start + 1);
                    String firstVal = "";
                    String secondVal = "";

                    for (int i=0; i < first.length(); i++) {
                        if (first.charAt(i) != ' ') {
                            firstVal = firstVal + first.charAt(i);
                        }
                    }
                    for (int i=0; i < second.length(); i++) {
                        if (second.charAt(i) != ' ') {
                            secondVal = secondVal + second.charAt(i);
                        }
                    }

                    LinkedListS<Integer> val1 = new LinkedListS<>();
                    LinkedListS<Integer> val2 = new LinkedListS<>();

                    for (int i = firstVal.length() - 1; i >= 0; i--) {
                        String insert = firstVal.substring(i, i+1);
                        int val = Integer.parseInt(insert);
                        val1.add(val);
                    }

                    for (int i = secondVal.length() - 1; i >= 0; i--) {
                        String insert = secondVal.substring(i, i+1);
                        int val = Integer.parseInt(insert);
                        val2.add(val);
                    }

                    Arithmetic.multiply(val1, val2);

                }

                else if (input.contains(ex)) {
                    int start = 0;
                    for (int i=0; i < input.length(); i++) {
                        if (input.charAt(i) == '^') {
                            start = i;
                        }
                    }

                    String first = input.substring(0, start);
                    String second = input.substring(start + 1);
                    String firstVal = "";
                    String secondVal = "";

                    for (int i=0; i < first.length(); i++) {
                        if (first.charAt(i) != ' ') {
                            firstVal = firstVal + first.charAt(i);
                        }
                    }
                    for (int i=0; i < second.length(); i++) {
                        if (second.charAt(i) != ' ') {
                            secondVal = secondVal + second.charAt(i);
                        }
                    }

                    LinkedListS<Integer> val1 = new LinkedListS<>();
                    int val2 = Integer.parseInt(secondVal);

                    for (int i = firstVal.length() - 1; i >= 0; i--) {
                        String insert = firstVal.substring(i, i+1);
                        int val = Integer.parseInt(insert);
                        val1.add(val);
                    }

                    Arithmetic.power(val1, val2);

                }


            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + infile.getPath());
        }
    }
}
