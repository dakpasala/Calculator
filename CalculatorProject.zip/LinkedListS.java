public class LinkedListS<T> {
    private Node<T> head;
    private int size;


    public LinkedListS() {
        this.head = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void add(T data) {
        Node<T> newNode = new Node<>(data);
        if (isEmpty()) {
            head = newNode;
        }
        else {
            Node<T> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        size++;
    }

    public T removeFirst() {
        if (isEmpty()) {
            return null;
        }
        else {
            T data = head.data;
            head = head.next;
            size--;
            return data;
        }
    }

    public T removeLast() {
        if (isEmpty()) {
            return null;
        }
        else if (head.next == null) {
            T data = head.data;
            head = null;
            size--;
            return data;
        }
        else {
            Node<T> current = head;
            while (current.next.next != null) {
                current = current.next;
            }
            T data = current.next.data;
            current.next = null;
            size--;
            return data;
        }
    }

    public T get(int index) {
        Node<T> current = head;
        for (int i=0; i < index; i++) {
            current = current.next;
        }
        return current.data;
    }

    public void set (int index, T data) {
        Node<T> current = head;
        for (int i=0; i < index; i++) {
            current = current.next;
        }
        current.data = data;
    }

    public int size() {
        return size;
    }
}
