
import java.util.*;

public class Arithmetic {

    public static void add1(LinkedListS<Integer> a, LinkedListS<Integer> b) {
        for (int i = a.size() - 1; i >= 0; i--) {
            System.out.print(a.get(i));
        }
        System.out.print(" + ");
        for (int i = b.size() - 1; i >= 0; i--) {
            System.out.print(b.get(i));
        }
        LinkedListS<Integer> result = new LinkedListS<>();
        int carry = 0;
        while (!a.isEmpty() || !b.isEmpty()) {
            int sum = carry;
            if (!a.isEmpty()) {
                sum += a.removeFirst();
            }
            if (!b.isEmpty()) {
                sum += b.removeFirst();
            }
            result.add(sum % 10);
            carry = sum / 10;
        }
        if (carry > 0) {
            result.add(carry);
        }
        int index = 0;
        for (int i=0; i < result.size(); i++) {
            if (result.get(i) != 0) {
                index = i;
            }
        }

        System.out.print(" = ");
        for (int i = index; i >=0; i--) {
            System.out.print(result.get(i));
        }
         System.out.println("");
    }

    public static void multiply (LinkedListS<Integer> a, LinkedListS<Integer> b) {

        LinkedListS<Integer> result = multiply1(a, b);
//        for (int i=0; i < a.size() + b.size(); i++) {
//            result.add(0);
//        }
//        for (int i=0; i < a.size(); i++) {
//            int carry = 0;
//            for (int j = 0; j < b.size(); j++) {
//                int product = a.get(i) * b.get(j) + carry + result.get(i+j);
//                result.set(i+j, product % 10);
//                carry = product / 10;
//            }
//            result.set(i+b.size(), carry);
//        }
        int index = 0;
        for (int i=0; i < result.size(); i++) {
            if (result.get(i) != 0) {
                index = i;
            }
        }
        for (int i = a.size() - 1; i >= 0; i--) {
            System.out.print(a.get(i));
        }
        System.out.print(" * ");
        for (int i = b.size() - 1; i>=0; i--) {
            System.out.print(b.get(i));
        }
        System.out.print(" = ");
        for (int i = index; i >=0; i--) {
            System.out.print(result.get(i));
        }
        System.out.println("");
    }


    public static LinkedListS<Integer> multiply1 (LinkedListS<Integer> a, LinkedListS<Integer> b) {
        LinkedListS<Integer> result = new LinkedListS<>();
        for (int i=0; i < a.size() + b.size(); i++) {
            result.add(0);
        }
        for (int i=0; i < a.size(); i++) {
            int carry = 0;
            for (int j = 0; j < b.size(); j++) {
                int product = a.get(i) * b.get(j) + carry + result.get(i+j);
                result.set(i+j, product % 10);
                carry = product / 10;
            }
            result.set(i+b.size(), carry);
        }
        return result;
    }
    public static void power (LinkedListS<Integer> x, int n) {
        LinkedListS<Integer> result = power1(x, n);
        int index = 0;
        for (int i=0; i < result.size(); i++) {
            if (result.get(i) != 0) {
                index = i;
            }
        }
        for (int i = x.size() - 1; i>= 0; i--) {
            System.out.print(x.get(i) + "");
        }
        System.out.print(" ^ " + n + " = ");

        for (int i = index; i >=0; i--) {
            System.out.print(result.get(i));
        }
       System.out.println("");
    }
    public static LinkedListS<Integer> power1(LinkedListS<Integer> x, int n) {
        if (n == 0) {
            LinkedListS<Integer> result = new LinkedListS<Integer>();
            result.add(1);
            return result;
        }
        LinkedListS<Integer> y = power1(x, n/2);
        y = multiply1(y, y);
        if (n % 2 == 1) {
            y = multiply1 (y, x);
        }
        return y;
    }


}
